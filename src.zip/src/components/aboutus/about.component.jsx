import React from 'react'

export const AboutComponent = () => {
  return (
    <div>about.component</div>
  )
}
