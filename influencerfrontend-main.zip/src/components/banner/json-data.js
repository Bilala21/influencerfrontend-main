export const popular_searches = [
    {
        'label': "Designer",
        'url': "/home",
    },
    {
        'label': "Developer",
        'url': "/",
    },
    {
        'label': "Web",
        'url': "/",
    },
    {
        'label': "IOS",
        'url': "/",
    },
    {
        'label': "PHP",
        'url': "/",
    },
    {
        'label': "Senior",
        'url': "/",
    },
]


