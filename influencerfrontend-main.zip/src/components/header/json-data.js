export const links = [
    {
        'label': "Home",
        'url': "/",
    },
    {
        'label': "How it Works",
        'url': "/howitworks",
    },
    {
        'label': "Market",
        'url': "/qq",
    },
    {
        'label': "Support",
        'url': "/qqq",
    },
    {
        'label': "Promiose Bond",
        'url': "/qqq",
    },
    {
        'label': "Contact",
        'url': "/about-us",
    },
]
export const become_a_seller =
{
    'label': "Become a Seller",
    'url': "/qqq",
}
export const login = {
    'label': "Log In",
    'url': "/signin",
}
export const sign_up = {
    'label': "Sign Up",
    'url': "/signup",
}
export const categories = {
    'label': "Categories",
    'url': "/qqqq",
}

